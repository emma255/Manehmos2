<div class="text-right col-md-12">
    <footer class="footer">
        <p>&copy;2018 - {{ date('Y') }} Manehmos</p>
    </footer>
</div>
