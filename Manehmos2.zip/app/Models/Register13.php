<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Register13 extends Model
{
    protected $guarded = [];
}
