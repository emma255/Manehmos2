<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Alipojifungua_view extends Model
{
    protected $table = 'alipojifungua';
}
