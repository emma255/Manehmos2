<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Maelezo_view extends Model
{
    protected $table = 'maelezo';
}
