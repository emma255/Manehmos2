<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Postnatal extends Model
{
    protected $guarded = [];
}
