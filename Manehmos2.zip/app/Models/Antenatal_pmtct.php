<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Antenatal_pmtct extends Model
{
    protected $table = 'antenatal_pmtct';
}
