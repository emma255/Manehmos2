<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FamilyPlan extends Model
{
    protected $table = 'family_plan';
}
