<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mtoto_huduma extends Model
{
    protected $table = 'mtoto_huduma';
}
