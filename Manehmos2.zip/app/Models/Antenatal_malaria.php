<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Antenatal_malaria extends Model
{
    protected $table = 'antenatal_malaria';
}
