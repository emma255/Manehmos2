<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mtoto_lishe extends Model
{
    protected $table = 'mtoto_lishe';
}
