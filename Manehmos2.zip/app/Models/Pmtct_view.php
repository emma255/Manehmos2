<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pmtct_view extends Model
{
    protected $table = 'pmtct';
}
